<div class="container-fluid topSection">
<div class="container">

		<div class="col-md-6 text-left leftQuickLink">
			<a href="javascript:void(0);">Human Health</a>
			<a href="javascript:void(0);">Animal Care</a>
			<a href="javascript:void(0);">Herbs Natural</a>
		</div>
		<div class="col-md-6 text-right rightQuickLink"> 
			<a href="javascript:void(0);">Careers</a>
			<a href="javascript:void(0);">Contact us</a>
			<a href="javascript:void(0);">Downloads</a>
		</div>

</div>
</div>

<div class="container-fluid headerSection">
		<div class="col-md-5">
			<ul class="nav nav-pills pull-right">
				<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About Us <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="javascript:void(0);">Overview</a></li>
						<li><a href="javascript:void(0);">Corporate Philosophy</a></li>
						<li><a href="javascript:void(0);">Vision Mission</a></li>
						<li><a href="javascript:void(0);">Strengths </a></li>
						<li><a href="javascript:void(0);">Corporate identity</a></li>
						<li><a href="javascript:void(0);">Group companies</a></li>
						<li><a href="javascript:void(0);">Social responsibility</a></li>
          </ul>
        </li>
				<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Business Areas <span class="caret"></span></a>
          <ul class="dropdown-menu">
						<li><a href="javascript:void(0);">Human health</a></li>
						<li><a href="javascript:void(0);">Animal care</a></li>
						<li><a href="javascript:void(0);">Strengths </a></li>
						<li><a href="javascript:void(0);">Corporate identity</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Operations <span class="caret"></span></a>
          <ul class="dropdown-menu">
						<li>
						<a href="javascript:void(0);">Research &amp; Development</a></li>						<li>
						<a href="javascript:void(0);">Production &amp; Packaging</a></li>						<li>
						<a href="javascript:void(0);">Quality Control &amp; Assurance</a></li>						<li>
						<a href="javascript:void(0);">Distribution &amp; Supply chain</a></li>						<li>
						<a href="javascript:void(0);">Regulatory &amp; Medical affairs</a></li>          </ul>
        </li>
			</ul>
		</div>
		<div class="col-md-2 text-center">
			<img src="images/weblogo.png" alt="gbpl logo">
		</div>
		<div class="col-md-5">
			<ul class="nav nav-pills">
				<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Services <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">One more separated link</a></li>
          </ul>
        </li>
				<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Product <span class="caret"></span></a>
          <ul class="dropdown-menu">
						<li><a href="javascript:void(0);">Prometheus</a></li>
						<li><a href="javascript:void(0);">Zooker</a></li>
          </ul>
        </li>
				<li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contact Us <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="javascript:void(0);">Our locations</a></li>
						<li><a href="javascript:void(0);">Contact</a></li>
						<li><a href="javascript:void(0);">Enquiry </a></li>
          </ul>
        </li>
			</ul>
		</div>
	</div>
	<div class='clearfix'></div>
