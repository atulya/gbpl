<footer class="container-fluid">
			<div class="container">
				<div class="firstRow row"><!-- firstRow -->
				<ul class="col-md-12">
					<li class="col-md-2">About Us
						<ul>
							<li><a href="aboutus.php">Overview</a></li>
							<li><a href="corporatePhilosophy.php">Corporate Philosophy</a></li>
							<li><a href="vision-mission.php">Vision Mission</a></li>
							<li><a href="coreStrengths.php">Strengths</a></li>
							<li><a href="corporateIdentity.php">Corporate identity</a></li>
							<li><a href="javascipt:void(0);">Group companies</a></li>
							<li><a href="socialResponsiblity.php">Social responsibility</a></li>
						</ul>
					</li>
					<li class="col-md-2">Business Areas
						<ul>
							<li><a href='businessHumanHealth.php'>Human health</a></li>
							<li><a href='businessAnimalCare.php'>Animal care</a></li>
							<!-- <li>Strengths </li> -->
							<li><a href='businessCorporateIdentity.php'>Corporate identity</a></li>
							
						</ul>
					</li>
					<li class="col-md-3">Operations
						<ul>
							<li>Research &amp; Development</li>
							<li>Production &amp; Packaging</li>
							<li>Quality Control &amp; Assurance</li>
							<li>Distribution &amp; Supply chain</li>
							<li>Regulatory &amp; Medical affairs</li>
						</ul>
					</li>
					<li class="col-md-2">Products
						<ul>
							<li>Prometheus</li>
							<li>Zooker</li>
						</ul>
					</li>
					<li class="col-md-3">Downloads
						<ul>
							<li>Corporate presentation</li>
							<li>Brochure</li>
							<li>News</li>
						</ul>
					</li>
					</ul>
				</div><!-- End firstRow -->
			<div class="secondRow row"><!-- secondRow -->
				<ul class="col-md-12">
					<li class="col-md-2">Careers
						<ul>
							<li>Life at GBPL</li>
							<li>Culture</li>
							<li>Send your CV </li>
						</ul>
					</li>
					<li class="col-md-2">Contact Us
						<ul>
							<li>Our locations</li>
							<li>Contact</li>
							<li>Enquiry </li>
						</ul>
					</li>
					<li class="col-md-3">Going Global
						<ul>
							<li>International Business</li>
							<li>Global sourcing</li>
						</ul>
					</li>
					<li class="col-md-2">Policies
						<ul>
							<li>Terms &amp; Condation</li>
							<li>Copyright</li>
							<li>Privacy Policy</li>
						</ul>
					</li>
					<li class="col-md-3">
						<ul>
							<li><i class="fa fa-facebook-square"></i><i class="fa fa-twitter-square"></i><i class="fa fa-google-plus-square"></i><i class="fa fa-linkedin-square"></i></li>
						</ul>
					</li>
					</ul>
				</div><!-- End secondRow -->
			</div>
			
		</div>
	</footer>
	
</body>
</html>
