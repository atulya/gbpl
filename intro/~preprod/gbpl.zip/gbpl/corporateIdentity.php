<?php include "routes.php"; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $projectName ?>  | Corporate identity</title>
    <?php include "assetCss.php"; ?>
  </head>
  <body>
    <?php include "header.php"; ?>
    <div class="innerpageBanner">
      <img src="images/3.jpg" alt="about us">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3>
            Corporate Identity
            </h3>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row innerContent">
        <div class="col-md-8 col-md-offset-2">
          <p>
            GBENNETTI is expression of God’s instinctive Blessings meant for holistic well-being and Quality of living of the global community and is represented by healthy happy living  
            <br><br>
            Our corporate identity is creative illustration of this healthy happy world and is the amalgamated artful craft of the symbolic lotus ,peacock and blossoming panoramic Life .
            <br><br>
            Symbolic identity: Here God’s instinctive is depictive of Lotus which symbolizes Origin,Purity (Nobility) and Abundance (Good luck, Health, wealth, prosperity &amp; care) of Life while Peacock is the harbinger of eternal sense of well-being( feeling of Happiness, success, good times ,glory and pride)
            <br><br>
            Together when peacock feathers get bonded with lotus petals, it forms an emblem that embodies vision, magnanimity, integrity, immortality, sophistication, good will and benevolence or generosity together with good health, happiness, success and glory. This emblem as a unique entity demystifies its ability to protect and transcend the horizons across darkness and light and a strong will power to mark happy beginnings growing with each other together in the torch of light.
          </p>
          <p>
            <ul>
              <li>
              Rich galore of research and development labs focused on innovation </li>
              <li>
              Global manufacturing alliances from API to finished dosages</li>
              <li>
              International accreditations in all facilities </li>
              <li>
                Experienced management stalwarts and highly competent team
              </li>
            </ul>
            <span class="text-left">
            <div class="col-md-4">Mayuresh R. Abhyankar, Founder &amp; Managing Director, BPharm, MMM, PGDBM-IB, PGDCR, 16+ Exp</div>
            <div class="col-md-4">Priyadarshini Pawar, Chief Executive Officer, Mpharm,MBA –IIM calcutta, 15+ Exp</div>
            <div class="col-md-4">Rajendra Vidwans, Independent Director, BSc, 15+ Exp</div>
            </span>
          </p>
        </div>
      </div>
    </div>
    <?php include "footer.php"; ?>
    <?php include "assetJs.php"; ?>
