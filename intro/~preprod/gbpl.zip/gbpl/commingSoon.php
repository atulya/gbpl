<?php include "routes.php"; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $projectName ?> | Coming Soon</title>
    <?php include "assetCss.php"; ?>
  </head>
  <body>
    <?php include "header.php"; ?>
    <div class="innerpageBanner">
      <img src="images/3.jpg" alt="about us">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3>
            
            </h3>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row innerContent">
        <div class="col-md-8 col-md-offset-2">
          <!--           <h1>Heading One</h1>
          <h2>Heading Two</h2>
          <h3>Heading Three</h3> -->
         <h2 class='text-center'>Coming Soon</h2>
   
</div>
</div>
</div>
<?php include "footer.php"; ?>
<?php include "assetJs.php"; ?>
