<?php include "routes.php"; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $projectName ?>  | Corporate identity</title>
    <?php include "assetCss.php"; ?>
  </head>
  <body>
    <?php include "header.php"; ?>
    <div class="innerpageBanner">
      <img src="images/3.jpg" alt="about us">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3>
            Corporate Identity
            </h3>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row innerContent">
        <div class="col-md-8 col-md-offset-2">
          <blockquote>
            <h3>B’coz every life is precious!</h3>
          </blockquote>
          <p>
            At GBPL,  the act of ‘giving back’ to the society in which we thrive goes beyond the paradigm of care.  We believe our onus is much above the economic threshold of making profits or performing within the legal barriers of mere existence. We aspire to rise above the ethical standards and shine on the morality of social ground to touch the precious billion hearts on this universe preserving their today and transforming a better living for tomorrow .Our ‘corporate rhythm’, GBPL Ezekiel Foundation (GEF) is a charitable trust registered in Hong Kong and represents GBPL’s rising spirit, compassion and dedication in serving the communities and the biosphere in which it operates around the world.
            <br><br>
            1) Biosphere security:  Under this initiative, GEF has undertaken developmental and protective roadmap towards Hydrosphere, Lithosphere and Atmosphere which constitute biosphere and work to address various habitative needs of Life and Living. 
            <br><br>
            a) Environmental protection – Harnessing the need to preserve and protect the vital natural resources, GEF has embarked on GO GREEN programs across the organization. These programs play a key role in impacting climate change, water use footprint and energy efficiency.  GO GREEN programs are measures to reflect awareness of our interconnectedness with the world and make environmental responsibility a reality.
            <br><br>
            GEF’s GO GREEN programs advocate 5 R’s in the interest of biosphere: 
            <ul>
              <li>
                Reduce: Wastes, Power consumption, Fuel and pollution
              </li>
              <li>
                Reuse: Plastic, Scrap paper and Utilities.                
              </li>
              <li>
                Recycle:  Water, Bottles, Cans, Paper and Soil.               
              </li>
              <li>
                Reignite: Environmental friendly products usage, energy-efficient technology                
              </li>
              <li>
                Restore: Vegetarianism in food consumption, eco-friendly office supplies.                 
              </li>
              <li>
                 b) Ecosystem Development
                 <br><br>
                - This includes promotion of Agriculture &amp; Animal husbandry. Our involvement in agriculture arena is primarily for crop harvestation, flora and fauna farming and productivity augmentation. In animal husbandry sector, we focus on livestock development, animal health facilities and productivity outcome measures. 
              </li>
            </ul>
              2) Community welfare:  GEF is dedicated to communities in which we habitat and strive relentless to ascertain greater control over the conditions that affect their living. In partnership with the public and private sectors, civic societies, and the philanthropic communities, GEF provides knowledge and solutions to build the faculty of needy communities and so also furnish them with the necessary resources to improve the quality of their lives and help sustainable economic development.  
              <br><br>
              a) Rural Youth Development  &amp; Women empowerment – GEF aims at letting rural communities lead poverty free progressive disease-free life. In alliance with host of international institutions and socio-civic groups such as community centers, NGO s  etc the foundation accelerates the momentum and magnitude of change by promoting skill development, leadership and employability of rural population, particularly women  and youth . In certain situations, the Foundation acts as a catalyst between generous partners and the underprivileged by facilitating timely micro-finance support and enabling them to become small-scale entrepreneurs.
              <br><br>
              b) Health &amp; Hygiene -  Rural people living in remote areas have no formal education systems and no health care centres. Malnutrition is prominent and there is no safe drinking water, sanitation and hygiene. Under such conditions, diseases are inevitable with women and children suffering the most.
              <br><br>
              Qualitative health care is the most basic need such rural areas. GEF has developed a network of Healthcare Administrators within the communities for providing primary level curative and preventive health services through government and private Health care facilities partnership. Greater emphasis is laid on health seeking behavior in the areas of Tobacco de-addiction, Nutrition, HIV/AIDS infections, skin diseases, Tuberculosis, water-borne diseases etc.
              <br><br>
              Mobile clinics with doctor and Multi-specialty health camps are also organized to cater to special needs of population like cataract operations, Tetnus injections, haemoglobin check- up etc. Training and awareness sessions are conducted to mobilize people towards health and hygiene.
              <br><br>
              c) Urban Living: Rural population should have the same quality living  as is enjoyed by sub urban and urban people. Recognising that education is a fundamental human right and a binding force to achieve urban living zenith, GEF aims to reach out and provide life-changing educational opportunities to those needy in the community. GEF stands for individuals and children who aspire to realise their full potential, lead prolific lives and contribute to the economic welfare through education and urbanisation. 
              <br><br>
              For this, GEF has partnered with leading institutions around the world facilitating e-learning educational systems that make education exciting, easy and convenient. This initiative has not only improved the quality of education but has also improved retention and made whole educational endevour cost effective and accessible.  At the same time to promote lifestyle enhancement, GEF also fosters creation of multiracial multicultural heritage community through support of traditional and contemporary dance, music, sports and the arts. By reinstating craftsmanship, GEF intends to revitalise the cultural synergy in the community as a whole and make lifestyle a vital part of daily urban living system.
          </p>
        </div>
      </div>
    </div>
    <?php include "footer.php"; ?>
    <?php include "assetJs.php"; ?>
