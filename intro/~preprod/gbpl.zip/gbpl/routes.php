<?php 

	$baseURL = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']; 
	$projectName = "Gbennetti Life";
	$assetCss = "css/";
	$assetJs = "js/";
	$assetImg = "images/";

?>

