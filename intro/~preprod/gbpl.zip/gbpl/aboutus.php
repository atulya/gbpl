<?php include "routes.php"; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $projectName ?>  | Overview</title>
    <?php include "assetCss.php"; ?>
  </head>
  <body>
    <?php include "header.php"; ?>
    <div class="innerpageBanner">
      <img src="images/3.jpg" alt="about us">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3>
            Overview
            </h3>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row innerContent">
        <div class="col-md-8 col-md-offset-2">
          <!--           <h1>Heading One</h1>
          <h2>Heading Two</h2>
          <h3>Heading Three</h3> -->
          <p>
            At GBennetti, since inception in 2010, we are here to bless the lives of billions around the world with our innovative cost-effective range of healthcare products and services that enliven the quality of Living and wellbeing, truly transcending as a boon to Life.
            <br />
            <br />
            Giving a benevolent healing hand in burgeoning healthcare, Gbennetti has evolved fundamentally as a specialized healthcare group focused on human health, animal care and herbal wellness as its primary business offerings. We are committed to deliver sustainable affordable and reliable pedigree of innovative qualitative solutions for betterment of Life and the living.
            <br />
            <br />
            With global representation in Unites States -Texas, the group stands tall on its levers of cutting-edge science, operational brilliance, intellectual meritocracy, insightful technology, world-class capabilities and dynamic supply chain leveraging state-of-the art global capacities.
            <br />
            <br />
            Our cost-effective bio-comparative high quality generics help progressing human life and animal health in critical life-threatening conditions as well as Lifestyle conditions providing real value for money. Our bio-devices specialty products alleviate the pain and the sufferings by both diagnostic and treatment measures.  While herbal range offerings provide standardized nutritional value and enriched personal care.
            <br />
            <br />
            Count on Gbennetti, count on our Products and Services. Life is now a boon-omnipotent, omnipresent and omniscient!
          </p>
          <p>
            Synopsis :
            <ul><li>
            An integrated global healthcare organization with presence in more than 20+ countries.</li>
            <li>
            Headquartered in the Heart of India-Mumbai and having representation offices in northern and southern India and globally in USA, Malaysia, Dubai and China.</li>
            <li>
            Fast growing company engaged in research, manufacturing and global marketing of a broad range of pharmaceutical, life sciences and herbal products  (200+ products)</li>
            <li>
              One of widest therapeutic segments coverage catering to the consumer healthcare (the Mass) as well as Super specialty care including biologics (the Class)
            </li>
            <li>
              One of the largest dosage form bandwidth serving topical, oral , invasive as well intensive care products in diagnostic, curative as well as palliative healthcare
            </li>
            <li>
              High quality, safe, cost-effective and reliable products and services
            </li>
            <li>
              Unbiased thrust on delivering performance in 4 key growth levers-
            </li>
            <li>
              Innovation in research,
            </li>
            <li>
              Excellence in operations,
            </li>
            <li>
              Value for money in products and
            </li>
            <li>
              Speed in delivery
            </li>
            <li>
              Global partnerships ensuring value chain optimization and new generation innovation.
            </li>
            <li>
              World class research and manufacturing alliances across the globe rendering high quality premise
            </li>
            <li>
              Excellent regulatory track record with multiple accreditations from its alliance partners such as WHO GMP, WHO Geneva, USFDA, EuGMP, TGA, PPB, TFDA etc
            </li>
          </li>
        </ul>
      </p>
    </div>
  </div>
</div>
<?php include "footer.php"; ?>
<?php include "assetJs.php"; ?>
